import { Component } from '@angular/core';

@Component({
  selector: 'app-don-argent',
  standalone: true,
  imports: [],
  templateUrl: './don-argent.component.html',
  styleUrl: './don-argent.component.css'
})
export class DonArgentComponent {

}
